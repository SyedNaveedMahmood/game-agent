# Retry Diagnosis Prompt

## Context

- **Run ID**: `1015-201445`
- **Total retries**: 1
- **Time range**: 0.0s
- **Retry rate** (retries per decision): 0.062

## Error Breakdown

| Error Type | Count |
|---|---|
| validation_schema | 1 |

## Root Cause Hints

| Root Cause | Count |
|---|---|
| schema_mismatch | 1 |

## Detected Patterns

- Error type 'validation_schema' dominates (1/1). Focus debugging there.

## Top Issues with Raw Output Samples

### 1. validation_schema

**Agent agent_2, step 2, attempt 1**

Error: `Your response failed to match the expected schema. Please try again. Field ('action',) - Field required (error type: missing)`


## Analysis Request

Based on these patterns, what changes to prompts, validation, or retry logic would reduce the retry rate?
