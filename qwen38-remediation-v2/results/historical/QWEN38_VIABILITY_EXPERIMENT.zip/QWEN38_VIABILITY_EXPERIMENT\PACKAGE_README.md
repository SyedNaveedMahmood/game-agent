﻿# Qwen 3.8-27B viability evaluation package

This folder contains the local-inference changes, evaluation runner and supervisor, regression test, complete capability-evaluation report, and raw evidence for Experiments A, B, and C. It also contains the earlier two-round setup smoke artifacts cited by the report.

The package preserves repository-relative paths so these files can be compared with or copied back into the repository. Start with `reports/QWEN38_CAPABILITY_EVALUATION.md`.

The downloaded GGUF model, llama.cpp binaries, and Python virtual environment are not included; they are large runtime dependencies rather than experiment evidence. The full 80-life-step experiment was not run.
